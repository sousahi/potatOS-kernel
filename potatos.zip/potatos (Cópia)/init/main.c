void _start() {
    // Código de usuário simples
    while(1) {
        __asm__ volatile("nop");
    }
}
